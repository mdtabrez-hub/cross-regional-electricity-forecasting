**Table 7. Calibration of nominal 90% intervals for unseen BAs (random folds, test period). Widths and interval scores (IS) are in % of mean load.**

|   h (h) | Method                                                |   Mean cov. % | Min–max cov. %   |   BAs > 5 pp under % |   Median hourly width % |   Median IS % |
|--------:|:------------------------------------------------------|--------------:|:-----------------|---------------------:|------------------------:|--------------:|
|       1 | QR                                                    |          83.9 | 64.8–97.5        |                   52 |                    4.2  |          7.4  |
|       1 | SCP                                                   |          87.5 | 52.6–98.9        |                   31 |                    4.78 |          7.72 |
|       1 | CQR                                                   |          88.1 | 69.2–98.7        |                   33 |                    4.74 |          7.21 |
|       1 | SCP-T4                                                |          86.9 | 74.3–96.5        |                   29 |                    4.3  |          7.81 |
|       1 | ACI-CQR (γ = 0.005, frozen protocol)                  |          90   | 89.9–90.2        |                    0 |                    4.9  |          7.4  |
|       1 | ACI-CQR-V (γ on held-out BAs' 2023 data; exploratory) |          90   | 89.7–90.4        |                    0 |                    4.9  |          7.13 |
|      24 | QR                                                    |          87.3 | 76.1–96.1        |                   29 |                   17.15 |         28.26 |
|      24 | SCP                                                   |          88.9 | 71.4–99.3        |                   29 |                   20.14 |         31.88 |
|      24 | CQR                                                   |          89.2 | 78.6–97.3        |                   21 |                   18.14 |         28.15 |
|      24 | SCP-T4                                                |          85.3 | 60.8–95.9        |                   40 |                   14.97 |         34.15 |
|      24 | ACI-CQR (γ = 0.005, frozen protocol)                  |          90   | 89.8–90.2        |                    0 |                   18.6  |         88.55 |
|      24 | ACI-CQR-V (γ on held-out BAs' 2023 data; exploratory) |          89.9 | 89.4–90.5        |                    0 |                   17.81 |         28.24 |
