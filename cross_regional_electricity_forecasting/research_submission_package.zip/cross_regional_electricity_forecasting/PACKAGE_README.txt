Research submission package. Start with README.md (exact reproduction commands), then
manuscript/manuscript_final.docx, FINAL_QA_REPORT.md and RESEARCH_STATUS.md (author actions).
Raw data are not included: run `python -m src.download_data` (SHA-256 verified).
Compact test predictions are in the separate predictions_supplement.zip.
